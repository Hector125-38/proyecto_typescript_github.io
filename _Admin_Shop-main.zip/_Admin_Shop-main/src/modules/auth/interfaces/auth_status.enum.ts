export enum AuthStatus {
  Authenticated = 'Authenticated',
  Unauthenticated = 'Unauthenticated',
  Checking = 'Checking',
}
