<template>
  <div>
    <div class="grid grid-cols-3 gap-6">
      <div class="h-24 col-span-1 bg-white border border-gray-300"></div>
      <div class="h-24 col-span-1 bg-white border border-gray-300"></div>
      <div class="h-24 col-span-1 bg-white border border-gray-300"></div>
      <div class="h-24 col-span-2 bg-white border border-gray-300"></div>
      <div class="h-24 col-span-1 bg-white border border-gray-300"></div>
      <div class="h-24 col-span-1 bg-white border border-gray-300"></div>
      <div class="h-24 col-span-2 bg-white border border-gray-300"></div>
      <div class="h-24 col-span-3 bg-white border border-gray-300"></div>
      <div class="h-24 col-span-1 bg-white border border-gray-300"></div>
      <div class="h-24 col-span-1 bg-white border border-gray-300"></div>
      <div class="h-24 col-span-1 bg-white border border-gray-300"></div>
      <div class="h-24 col-span-2 bg-white border border-gray-300"></div>
      <div class="h-24 col-span-1 bg-white border border-gray-300"></div>
      <div class="h-24 col-span-1 bg-white border border-gray-300"></div>
      <div class="h-24 col-span-2 bg-white border border-gray-300"></div>
      <div class="h-24 col-span-3 bg-white border border-gray-300"></div>
      <div class="h-24 col-span-1 bg-white border border-gray-300"></div>
      <div class="h-24 col-span-1 bg-white border border-gray-300"></div>
      <div class="h-24 col-span-1 bg-white border border-gray-300"></div>
      <div class="h-24 col-span-2 bg-white border border-gray-300"></div>
      <div class="h-24 col-span-1 bg-white border border-gray-300"></div>
      <div class="h-24 col-span-1 bg-white border border-gray-300"></div>
      <div class="h-24 col-span-2 bg-white border border-gray-300"></div>
      <div class="h-24 col-span-3 bg-white border border-gray-300"></div>
    </div>
  </div>
</template>

<script setup lang="ts"></script>

<style scoped></style>
